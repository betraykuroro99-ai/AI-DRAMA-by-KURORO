# Episode 1 — Apat na Plato

Start with PRODUCTION-READY-CHECKLIST.md and plan.json. This pack includes the original script-line/shot plan, updated image-upload manifests, prompt templates, prop design references and editable phone/text overlays. Nestor uses Algenib, selected by the user. The working edit target is 90 seconds; final durations depend on measured scene audio.

All new reference art was made in this chat. No Venice credits were used for this update. The earlier pilot has a $1 conservative tracked total. Full episode production awaits approval of a proposed $8 total cap including that $1.

Historical pilot files retained in the broader pack may include the rejected Gacrux voice; casting.json and current Nestor status are authoritative. The accepted male preview is Algenib/B.
