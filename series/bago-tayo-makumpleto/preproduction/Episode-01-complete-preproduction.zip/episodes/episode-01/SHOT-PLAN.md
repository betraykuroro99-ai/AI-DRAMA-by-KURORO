# Episode 1 — Apat na Plato

Working edit target: **90 seconds**, with normal-speed dialogue. Durations remain provisional until actual voice performances are measured.

| Shot | Edit target | Visible character | Dialogue | Action |
| --- | --- | --- | --- | --- |
| E01-S01 | 4s | nestor | None | Close view of the fourth plate being placed at the far empty chair; reveal exactly four plates and four empty glasses. Do not show a person in that chair. |
| E01-S02 | 9s | nestor | L01 | Nestor records his invitation into a portrait phone propped against a squat soy-sauce bottle. Medium close-up; his small hopeful smile changes only at the end. One visible speaker. |
| E01-S03 | 5s | nestor | None | Nestor glances toward Elena's empty far-head chair. His smile fades. Cut to his thumb deleting the recording; composite the phone UI in editing. No talking or mouth flapping. |
| E01-S04 | 6s | nestor | None | Nestor checks Elena's recipe notebook beside a small pot, tastes with a spoon, winces and adds a little water. A phone rings at the end. Stage cooking props deliberately; do not import the empty-kitchen state. |
| E01-S05 | 8s | lea | L02 | Lea sits in her simple rented room overseas, talking to a phone on a small desk. She tries to sound cheerful. Single-person medium close-up. Background and desk reference still required. |
| E01-S06 | 4s | nestor | L03 | Nestor answers with gentle disappointment, not anger. Phone stays on the counter, gaze toward it; small jaw movement only during speech. |
| E01-S07 | 5s | lea | L04 | Lea avoids the phone briefly, then offers to check flights. Reuse the same room and camera side as S05. |
| E01-S08 | 3s | nestor | L05 | Nestor leans slightly toward the phone and addresses Marco. Close his mouth immediately after the name; no invented extra words. |
| E01-S09 | 7s | marco | L06 | Marco answers from a stationary sheltered spot on a Filipino street, wearing his olive shirt beneath a plain dark delivery jacket. Do not show him riding while calling. Separate street/wardrobe references still required. |
| E01-S10 | 4s | nestor | L07 | Nestor makes the small request, then waits with mouth closed. Hold his eyes, not an extended speaking animation. |
| E01-S11 | 5s | lea | L08 | After a brief uncomfortable beat, Lea ends the call. One visible speaker. No mouth movement after her line. |
| E01-S12 | 4s | nestor | None | The call ends. Nestor lowers his eyes to the recipe notebook. Use a meaningful short reaction, not a long static pause. |
| E01-S13 | 6s | Detail insert | None | Nestor's hands clear Lea's old bed, shake a pillow, find an old hair tie and place it on the dressing table. Keep the sequence concise; a bedroom/prop composition reference is still required. |
| E01-S14 | 3s | nestor | None | Blue dusk on the veranda. Nestor sits quietly with the phone, distant neighbor Christmas lights behind him. Main home remains undecorated. |
| E01-S15 | 8s | nestor | L09 | Nestor calls Elena's old number and softly speaks while waiting. Small natural mouth articulation, then stillness. Only Nestor is present. No ghost, response or supernatural effect. |
| E01-S16 | 4s | marco | None | Marco enters his bedroom after work. A phone rings from the drawer. He stops and turns toward it. Bedroom reference still required. |
| E01-S17 | 5s | marco | None | Marco opens the drawer and lifts Elena's old phone. End on a close-up of the incoming call. The exact PAPA CALLING interface will be composited in editing, not generated as unreliable model text. |

## Assembly approach

Use short intentional cuts, not 15-second blocks. For adjacent phone-call turns, cut directly between single speakers and build the call interface in post. Keep enough silence to read Nestor's glance at the empty chair and the last phone reveal. Preserve wording; spelling in plan.json normalizes apostrophes only. No season generation has started.

## Reference work completed

The reference pack now includes Lea's overseas room and childhood bedroom, Marco's bedroom and sheltered delivery-call location, his delivery jacket variant, and the phone/notebook/hair-tie design board. Exact screen/recipe text overlays are in overlays/. Use reference-manifest.json for each shot's image order. Prepare shot-specific compositions as needed after dialogue timing; these references do not lock a first frame automatically. Main house remains undecorated in Episode 1.

## Indicative video allowance

If every edit shot were generated independently at the currently observed 5-second minimum, the initial requests would total 99 generated seconds rather than 90 used seconds. At the previously quoted $0.06/second, that is approximately $5.94 before voices and corrections. Combine compatible action beats where quality permits; re-quote before each paid submission. This is not an approved spending authorization.
