# Speaking test before paid episode production

## Purpose

Determine whether MiniMax H3 Max R2V can follow an approved Tagalog audio performance without excessive mouth animation. Do not assume that replacing a soundtrack will repair the generated mouth movement.

## Concrete test

- One visible speaker: Nestor only, chest-up in the dining room.
- 8-second request, 9:16, 480P.
- Images: @Image1 Nestor identity; @Image2 dining room; use a dedicated close composition if needed.
- Exact line: "Mga anak, sa bahay tayo ngayong Pasko. Kumpleto tayo."
- Record the approved voice first. Measure its actual speech onset/end and pauses.
- If the whole line cannot fit comfortably within 8 seconds with at least 0.75s silence before and after speech, increase request length to fit (maximum 15s) and re-quote. Never speed up the voice just to fit the test.
- Use only the currently documented audio-input field; reference audio support is not a guarantee of exact speech synchronization.

## Animation directions

Closed relaxed mouth before speech. Small natural jaw movement only on spoken syllables, minimal cheek movement. No exaggerated oval mouth shapes, repeated opening during pauses or continued talking after speech ends. Gentle eye movement and a restrained smile. The smile softens after "Kumpleto tayo." Do not add other people, speech, gestures or camera moves.

## Pass/fail review

1. Confirm words and speaker from transcription and human listening.
2. Inspect speech onset, pauses and ending frame by frame against the waveform. Flag persistent mouth motion in silence.
3. Inspect typical vowels for excessive mouth opening and repeated cycles.
4. Check identity and illustration style against the character reference.
5. Ask the user to judge naturalness from the actual clip before scaling to the episode.

Do not label a shot approved merely because transcript text is correct. If it fails, keep the take, log the problem and propose a revised prompt, cutaway coverage or a dedicated lip-sync workflow after checking available service support. Do not silently replace audio and claim lip sync was repaired.

## Proposed initial test cap

Request a NEW authorization of up to **$2 total** for four short voice auditions, a speaking test and verification, including any test retake that fits the cap. This is separate from the previous film's $20 authorization. Validate current voice/model availability, obtain live quotes and stop before exceeding the new approved cap. No paid requests have been made for the series.
