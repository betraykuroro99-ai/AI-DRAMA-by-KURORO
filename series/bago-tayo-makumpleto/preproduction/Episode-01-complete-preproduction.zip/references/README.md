# Bago Tayo Makumpleto — visual reference pack

Eight original images generated in this chat: one cast sheet, four individual character anchors and three empty location anchors. No Venice generation calls were made for this pack. These are working visual references; no season video/audio generation has been authorized or started.

## Art direction

Semi-realistic 2D anime-inspired Filipino family drama. Refined clean outlines, expressive moderately sized eyes, simplified elegant facial details, natural adult proportions, smooth cel shading with soft painted shadows, richly detailed Filipino backgrounds. Warm amber domestic light, cool blue December evenings. Avoid photorealism, 3D rendering, oversized doll eyes, exaggerated expressions, and excessive talking-mouth animation.

## Identity anchors

- Nestor, 62: salt-and-pepper hair, navy polo, charcoal trousers, black shoes.
- Lea, 32: shoulder-length brown hair, burgundy blouse, indigo jeans, cream flats.
- Marco, 28: short black hair, olive T-shirt, brown trousers, off-white sneakers.
- Elena, 58 in memories: low bun, dusty rose floral house dress, brown slippers. Appears only as an ordinary living mother in recordings/flashbacks, never as a ghost.

Neutral anchors control faces, bodies, hair and base clothing, not every pose or expression. Define scene-specific actions and wardrobe changes explicitly. Do not upload the whole cast sheet as the only identity reference for every shot; send only the needed individual characters plus the relevant location.

## Location and continuity notes

Dining-room baseline: four wooden chairs, empty rectangular table, rear window with cream curtains, front/veranda door at left, low wooden sideboard at right, kitchen doorway at rear right. Empty chair by the back window is Elena's usual place. No plates or food in the baseline; add exactly the required place settings per scene.

Kitchen baseline: pale mint cupboards, louvered window over sink, tiled counter, right-hand stove and aluminum pot, wall shelves. No cooking fire or steam in neutral reference; specify cooking state per shot.

Veranda baseline: covered timber veranda, cream railing, brown-beige tiles, dark wooden front door and potted plants. Main house lights/parol have not yet been hung. Distant neighbor decorations are permitted. Add and track the family's Christmas decorations only when the episode calls for them.

The separately generated sets are visual guides, not a measured architectural model. Use a scene-specific composition reference when exact camera geography matters.

## Production handoff

Final video target is 9:16 portrait at 480p. High-resolution reference stills are intentional and do not change that video specification. References guide identity and style; they do not guarantee poses, staging or lip sync.

Plan short purposeful shots around measured approved dialogue. Prefer one visible speaker, explicit mouth-closed silence for listeners, and restrained facial motion. Before spending on the season, perform a short speaking test to evaluate actual audio following and mouth motion. The proposed season budget remains an estimate until the user explicitly approves a new cap.
